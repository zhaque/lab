.. django-extensions documentation master file, created by
   sphinx-quickstart on Wed Apr  1 20:39:40 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to django-extensions's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 3

   admin_extensions
   command_extension_ideas
   command_extensions
   dumpscript
   export_emails
   field_extensions
   graph_models
   installation_instructions
   jobs_scheduling
   mercurial_gateway
   model_extensions
   namespace_proposal
   runprofileserver
   runserver_plus
   sync_media_s3


Indices and tables
==================

* :ref:`search`

