from runtests import buildTestSuite
