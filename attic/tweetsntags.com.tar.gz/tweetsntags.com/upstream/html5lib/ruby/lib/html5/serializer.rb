require 'html5/serializer/htmlserializer'
require 'html5/serializer/xhtmlserializer'
